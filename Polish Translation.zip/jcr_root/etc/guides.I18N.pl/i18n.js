/*************************************************************************
 *
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

(function (guidelib) {
    guidelib.i18n = {
        "calendarSymbols":{
            "monthNames":["januari","februari","mars","april","maj","juni","juli","augusti","september","oktober","november","december"],
            "abbrmonthNames":["jan","feb","mar","apr","maj","jun","jul","aug","sep","okt","nov","dec"],
            "dayNames":["söndag","måndag","tisdag","onsdag","torsdag","fredag","lördag"],
            "abbrdayNames":["sön","mån","tis","ons","tor","fre","lör"],
            "meridiemNames":["AM","PM"],
            "eraNames":["a.C.","d.C."]
        },
        "datePatterns":{
            "full":"EEEE D' de 'MMMM' de 'YYYY",
            "long":"D' de 'MMMM' de 'YYYY",
            "med":"MMM D, YYYY",
            "short":"M/D/YY"
        },
        "timePatterns":{
            "full":"h:MM:SS A Z",
            "long":"h:MM:SS A Z",
            "med":"h:MM:SS A",
            "short":"h:MM A"
        },
        "dateTimeSymbols":"GuMtkhmsSEDFwWahKzZ",
        "numberPatterns":{
            "numeric":"z,zz9.zzz",
            "currency":"$z,zz9.99|($z,zz9.99)",
            "percent":"z,zz9%"
        },
        "numberSymbols":{
            "decimal":",",
            "grouping":".",
            "percent":"%",
            "minus":"-",
            "zero":"0"
        },
        "currencySymbols":{
            "symbol":"$",
            "isoname":"USD",
            "decimal":","
        },
        "typefaces":{}
    };
}(guidelib));
